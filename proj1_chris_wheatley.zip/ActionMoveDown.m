% This function move the blank/zero tile downwards by one, if possible, and
%   moves the displaced tile upwards by one where the blank tile began

function [Status, NewNode] = ActionMoveDown(CurrentNode)

% Find index of blank tile in current node
[i,j]=BlankTileLocation(CurrentNode);

New_node=CurrentNode;
NewNode=New_node;

ii=i+1;
jj=j;

NewNode(ii,jj)=0;
NewNode(i,j)=New_node(ii,jj);

Status=1;

end
