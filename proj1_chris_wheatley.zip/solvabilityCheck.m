% This function counts the number of inversions
%   that exist in the starting node. An even count means
%   that the puzzle is solvable, and an odd count means that
%   the puzzle is NOT solvable.

function [isSolvable]=solvabilityCheck(start_node)

[n,m]=size(start_node);
nums=[0 1 2 3 4 5 6 7 8];

for k=1:1:length(nums)
    h(k)=sum(sum(nums(k)==start_node));
end

if sum(h~=1)==0
    all_ones=1;
else
end

if or(n~=3,m~=3)==1
    isSolvable=0;
else
    tmp=start_node';
    newNode=tmp(:)';

    newNode(newNode==0)=[];

    counter=0;
    for i=1:1:length(newNode)
        if newNode(i)==0
        else
            val=newNode(i);
            for ii=i+1:1:length(newNode)
               if newNode(ii)==0
               else
                   if val>newNode(ii)
                       counter=counter+1;
                   else
                   end               
               end
            end
        end
    end

    isEven=~mod(counter,2);
end

% Delcare the starting node as "solvable" if the inversion count is even,
%   if the numbers 0,1,2,3,4,5,6,7,8 occur only once, and the input node is
%   a 3x3 matrix
if and(isEven==1,all_ones==1)
    isSolvable=1;
else
    isSolvable=0;
end

end
