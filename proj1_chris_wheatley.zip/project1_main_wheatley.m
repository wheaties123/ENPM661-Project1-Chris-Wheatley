% Chris Wheatley
% ENPM661 Spring 2020
% Project #1

% This script will solicit an airbirary 3x3 matrix from the user representing the starting position of an 8-tile
%   game with one empty space.  This program will then find the optimal
%   path to solved board (i.e. [1 2 3; 4 5 6; 7 8 0]).

clear all;

% Solicit input node configuration from user
fprintf('\n');
prompt = 'Enter the starting node configuration (use brackets an semi-colons to define a 3x3 matrix): ';
start_node = input(prompt);
fprintf('\n');

% Start program run timer
tic

% Define goal node configuration
goal_node= [1     2    3;...
            4     5    6;...
            7     8    0];
           
% Note that "0" indicates a blank tile

% Check if the puzzle is solvable
[isSolvable]=solvabilityCheck(start_node);

if isSolvable==1
    CurrentNode=start_node;

    ParentID=1;
    ParentID2=1;

    RunningNodes(ParentID).matrix=CurrentNode;
    RunningNodes(ParentID).Idx=ParentID;
    RunningNodes(ParentID).ParentIdx=0;

    % Find length of matrix
    [rows,cols]=size(start_node);
    nodeSize=rows*cols;

    while sum(sum(RunningNodes(ParentID2).matrix==goal_node))~=nodeSize


        % Find index of blank tile in current node
        [i,j]=BlankTileLocation(RunningNodes(ParentID2).matrix);

        if or(j==2,j==3)==1
            [Status, NewNode] = ActionMoveLeft(RunningNodes(ParentID2).matrix);
            % Moves blank tile left, if possible

            numNodes=length(RunningNodes);
            flag=0;
            for ii=1:1:numNodes
                if sum(sum(RunningNodes(ii).matrix==NewNode))==9
                    flag=1;
                else
                end
            end

            if flag==1
            else
                ParentID=ParentID+1;
                RunningNodes(ParentID).Idx=ParentID;
                RunningNodes(ParentID).matrix=NewNode;
                RunningNodes(ParentID).ParentIdx=ParentID2;
                RunningNodes(ParentID).move='Left';
            end
        else
        end

        % Find index of blank tile in current node
        [i,j]=BlankTileLocation(RunningNodes(ParentID2).matrix);
        if or(j==1,j==2)==1
            [Status, NewNode] = ActionMoveRight(RunningNodes(ParentID2).matrix);
            % Moves blank tile right, if possible

            numNodes=length(RunningNodes);
            flag=0;
            for ii=1:1:numNodes
                if sum(sum(RunningNodes(ii).matrix==NewNode))==9
                    flag=1;
                else
                end
            end

            if flag==1
            else 
                ParentID=ParentID+1;
                RunningNodes(ParentID).Idx=ParentID;
                RunningNodes(ParentID).matrix=NewNode;
                RunningNodes(ParentID).ParentIdx=ParentID2;
                RunningNodes(ParentID).move='Right';
            end
        else
        end

        [i,j]=BlankTileLocation(RunningNodes(ParentID2).matrix);
        % Find index of blank tile in current node
        if or(i==2,i==3)==1
            [Status, NewNode] = ActionMoveUp(RunningNodes(ParentID2).matrix);
            % Moves blank tile up, if possible

            numNodes=length(RunningNodes);
            flag=0;
            for ii=1:1:numNodes
                if sum(sum(RunningNodes(ii).matrix==NewNode))==9
                    flag=1;
                else
                end
            end

            if flag==1
            else
                ParentID=ParentID+1;
                RunningNodes(ParentID).Idx=ParentID;
                RunningNodes(ParentID).matrix=NewNode;
                RunningNodes(ParentID).ParentIdx=ParentID2;
                RunningNodes(ParentID).move='Up';
            end
        else
        end

        [i,j]=BlankTileLocation(RunningNodes(ParentID2).matrix);
        % Find index of blank tile in current node
        if or(i==1,i==2)==1
            [Status, NewNode] = ActionMoveDown(RunningNodes(ParentID2).matrix);
            % Moves blank tile down, if possible

            numNodes=length(RunningNodes);
            flag=0;
            for ii=1:1:numNodes
                if sum(sum(RunningNodes(ii).matrix==NewNode))==9
                    flag=1;
                else
                end
            end

            if flag==1
            else
                ParentID=ParentID+1;
                RunningNodes(ParentID).Idx=ParentID;
                RunningNodes(ParentID).matrix=NewNode;
                RunningNodes(ParentID).ParentIdx=ParentID2;
                RunningNodes(ParentID).move='Down';
            end
        else
        end


        ParentID2=ParentID2+1;
    end

    counter=1;
    backTrackFinished=ParentID2;
    Node(counter).Path=backTrackFinished;
    Node(counter).Move=RunningNodes(backTrackFinished).move;
    Node(counter).Matrix=RunningNodes(backTrackFinished).matrix;
    
    % Backtrack from the node index where the goal is satisfied until the
    %   backwards-running index equals 1
    while backTrackFinished~=1   
        counter=counter+1;
        backTrackFinished=RunningNodes(backTrackFinished).ParentIdx;
        Node(counter).Path=backTrackFinished;
        Node(counter).Move=RunningNodes(backTrackFinished).move;
        Node(counter).Matrix=RunningNodes(backTrackFinished).matrix;
    end

    Node=flip(Node);
    
    % Write results to text files
    fileID = fopen('nodePath.txt','w');
    fileID2 = fopen('NodesInfo.txt','w');   
    fileID3 = fopen('Nodes.txt','w');
    
    for i=1:1:length(Node)
        tmp=Node(i).Matrix';
        matrixx=tmp(:);
        for jj=1:1:length(matrixx)
            if jj==length(matrixx)
                fprintf(fileID, '%s\n',strcat(string(matrixx(jj)),{' '}));
            else
                fprintf(fileID, '%s',strcat(string(matrixx(jj)),{' '}));
            end
        end
    end 
    
    for i=1:1:length(RunningNodes)
        tmp=Node(length(Node)).Path;
        if i>tmp
        else
            fprintf(fileID2, '%s',strcat(string(RunningNodes(i).Idx),{' '}));
            fprintf(fileID2, '%s\n',strcat(string(RunningNodes(i).ParentIdx),{' '}));
        end   
    end

    for i=1:1:length(RunningNodes)
    tmpp=Node(length(Node)).Path;
        if i>tmpp
        else
        tmp=RunningNodes(i).matrix';
        matrixx=tmp(:);
            for jj=1:1:length(matrixx)
                if jj==length(matrixx)
                    fprintf(fileID3, '%s\n',strcat(string(matrixx(jj)),{' '}));
                else
                    fprintf(fileID3, '%s',strcat(string(matrixx(jj)),{' '}));
                end
            end
        end
    end 
    
    fclose(fileID);
    fclose(fileID2);
    fclose(fileID3);
    
else
    % Print out that the puzzle is not solvable if the user-specified input
    %   node either is not a 3x3 matrix or has an odd number of inversions
    disp('Input tile configuration is not solvable.');
end

fprintf('\n');

% End program run timer
toc

