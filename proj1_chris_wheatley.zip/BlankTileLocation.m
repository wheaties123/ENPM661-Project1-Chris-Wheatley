% This function ingests a matrix of arbitrary size and returns the i,j
%   location (i.e. row and column index) of where the blank tile is located
%   (i.e. where a 0 is located in the matrix)

function [i,j] = BlankTileLocation(CurrentNode)

[n,m]=size(CurrentNode);

for ii=1:1:n
    if ismember(0,CurrentNode(ii,:))==1
        i=ii;
    else
    end
end

for jj=1:1:m
    if ismember(0,CurrentNode(:,jj))==1
        j=jj;
    else
    end
end

end

